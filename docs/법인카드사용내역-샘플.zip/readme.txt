법인카드 사용내역 샘플파일입니다.

sample_C01.001  : 승인(Approval)
sample_C02.001  : 매입(Acquire)
sample_C03.001  : 청구(Bill)
sample_C04.001  : 카드기본(Card Info)
sample_C05.001  : 결제정보(Settlement)
sample_C06.001  : 한도정보(Card Limit)
